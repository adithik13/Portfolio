#include "process_log.h"
#include <sys/syscall.h>
#include <stdlib.h>
#include <string.h>

int get_proc_log_level(){
	int log_level =  syscall(GET_LOG_LEVEL);
	return log_level;
}
int set_proc_log_level(int new_level){
	int res = syscall(SET_LOG_LEVEL, new_level);
	return res;
}
int proc_log_message(int level, char *message){
	//char str[128];
	//if(strlen(str)  <128){
          //      return -1;
        //}
	int res = syscall(PROC_LOG_CALL, message, level);
	return res;
}
int* retrieve_set_level_params(int new_level){
	int *params = (int *)malloc(sizeof(int) * 3);
	params[0] = SET_LOG_LEVEL;
	params[1] = 1;
	params[2] = new_level;
	return params;
}
int* retrieve_get_level_params(){
	int *params = (int *)malloc(sizeof(int) *2);
	params[0] = GET_LOG_LEVEL;
	params[1] = 0;
	return params;
}
int interpret_set_level_result(int ret_value){
	return ret_value;
}
int interpret_get_level_result(int ret_value){
	return ret_value;
}
int interpret_log_message_result(int ret_value){
	return ret_value;
}
